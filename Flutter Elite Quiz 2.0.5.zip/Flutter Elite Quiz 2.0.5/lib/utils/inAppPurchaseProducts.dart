//in-app purchase products configuration

//
//Make sure to have same ids of consumable product in both play and app store
//
const Map<int, String> inAppPurchaseProducts = {
  //number of coins : it's respective consumable id
  5: "5_consumable_coins",
  10: "10_consumablr_coins",
  15: "15_consumable_coins",
};
